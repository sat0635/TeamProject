package com.example.acant.rayout;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //스플래시
        Intent intent = new Intent(this,SplashActivity.class);
        startActivity(intent);

        Button buttonparent = (Button)findViewById(R.id.parent_button);
        buttonparent.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intentparent = new Intent(getApplicationContext(),parent.class);
                startActivity(intentparent);
            }
        });

        Button buttonchildren = (Button)findViewById(R.id.children_button);
        buttonchildren.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intentchildren = new Intent(getApplicationContext(),children.class);
                startActivity(intentchildren);
            }
        });
    }
}
