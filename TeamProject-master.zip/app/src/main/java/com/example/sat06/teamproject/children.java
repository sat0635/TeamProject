package com.example.sat06.teamproject;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class children extends AppCompatActivity {

    static final Integer APP_PERMISSION = 1;
    private String temp;
    private String html = "";
    private Handler mHandler;

    private Socket socket;

    sendMessage send;

    private BufferedReader networkReader;
    private BufferedWriter networkWriter;

    private DataOutputStream writeSocket;
    private DataInputStream readSocket;

    private String ip = "155.230.91.229"; // IP
    private int port = 25569; // PORT번호


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_children);

        askForPermission(Manifest.permission.ACCESS_FINE_LOCATION, APP_PERMISSION);

        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        LocationListener locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) { //경위도 바뀔때마다 thread를 부름

                temp= showNewLocation(location);
                send = new sendMessage(socket);
                send.start();
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            @Override
            public void onProviderDisabled(String provider) {
            }
        };

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) // permission
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED)
            return;

        if (locationManager.getAllProviders().contains(LocationManager.NETWORK_PROVIDER))
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,0,0, locationListener);

        if (locationManager.getAllProviders().contains(LocationManager.GPS_PROVIDER))
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0, locationListener);
    }

    public void onClick(View view) {//자녀 위치 찾기 버튼 클릭시 지도가 뜨면됨.
        Intent intent = new Intent(children.this, mapMain.class );
        startActivity(intent);
    }

    public void onClick2(View view)
    {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:053-112"));
        startActivity(intent);
    }

    public void onClick3(View view)
    {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:010-1234-5678"));
        startActivity(intent);
    }


    // class sendMessage extends Thread{
    class sendMessage extends Thread{
        private Socket socket;
        DataOutputStream output;

        public sendMessage (Socket socket) {
            this.socket = socket;
        }

        public void run(){
            try{
                setSocket(ip, port);
                writeSocket = new DataOutputStream(socket.getOutputStream());

                OutputStream sender = socket.getOutputStream();
                InputStream receiver = socket.getInputStream();

                byte[] b;

//                final EditText et = (EditText) findViewById(R.id.EditText01);
                String return_msg = temp;

                b = return_msg.getBytes();
                sender.write(b,0,b.length);

                byte[] data = new byte[11];
                receiver.read(data,0,11);

                String message = new String(data);
//                TextView txv = (TextView)findViewById(R.id.chatting);
//                txv.setText(message);

            } catch(Exception e){
                final String recvInput = "메시지 전송 실패.";
                Log.d("Message", e.getMessage());
            }
        }
    }

    public void setSocket(String ip, int port) throws IOException {

        try {
            InetAddress addr = InetAddress.getByName(ip);
            socket = new Socket(ip, port);

            // networkWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            // networkReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            System.out.println(e);
            e.printStackTrace();
        }

    }

    class TCPServer implements Runnable {
        public static final int ServerPort = 25569;
        public static final String ServerIP = "155.230.91.229";

        //Message retMsg = Message.obtain();
        //retMsg.what;

        @Override
        public void run() {
            //Looper.prepare();
            try {
                setSocket(ip, port);
                // writeSocket = new DataOutputStream(socket.getOutputStream());
            } catch (Exception e) {
                e.printStackTrace();
            }
            //Looper.loop();
        }
    }

    private void askForPermission(String permission, Integer requestCode)
    {
        if(ContextCompat.checkSelfPermission(children.this, permission)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(children.this, permission)) {
                ActivityCompat.requestPermissions(children.this, new String[] {permission }, requestCode);
            } else {
                ActivityCompat.requestPermissions(children.this, new String[] {permission }, requestCode);
            }
        } else {
            Toast.makeText(this, "" + permission + " is already granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(ActivityCompat.checkSelfPermission(this, permissions[0]) == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
        }

    }
    private Location bestLocation = null;
    public String showNewLocation(Location location) { // ver 1
        // Provider

        if ( isBetterLocation(location, bestLocation)){
            Toast.makeText(this, "changed", Toast.LENGTH_SHORT).show();

            bestLocation = location;
        }
        location=bestLocation;


        return String.format("%f %f",location.getLongitude(),location.getLatitude());

    }
    private static  final int TWO_MINUTES = 1000*5;

    protected boolean isBetterLocation(Location location, Location currentBestLocation) {
        if (currentBestLocation == null) {
            return true;
        }

        long timeDelta = location.getTime() - currentBestLocation.getTime();
        boolean isSignificantlyNewer = timeDelta > TWO_MINUTES;
        boolean isSignificantlyOlder = timeDelta < -TWO_MINUTES;
        boolean isNewer = timeDelta > 0;

        if (isSignificantlyNewer) {
            return true;
        } else if (isSignificantlyOlder) {
            return false;
        }

        return false;
    }

    private boolean isSameProvider(String provider1, String provider2) {
        if (provider1 == null) {
            return provider2 == null;
        }
        return provider1.equals(provider2);
    }
}
