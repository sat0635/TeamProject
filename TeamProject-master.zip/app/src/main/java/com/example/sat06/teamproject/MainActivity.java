package com.example.sat06.teamproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //스플래시
        Intent intent = new Intent(this,SplashActivity.class);
        startActivity(intent);

        Button buttonparent = (Button)findViewById(R.id.parent_button);
        buttonparent.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intentparent = new Intent(getApplicationContext(),parent.class);
                startActivity(intentparent);
            }
        });

        Button buttonchildren = (Button)findViewById(R.id.children_button);
        buttonchildren.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intentchildren = new Intent(getApplicationContext(),children.class);
                startActivity(intentchildren);
            }
        });
    }

    public void onClick(View view) {//첫화면에서 번호를 받아서 로그인을 하는 형식임. 카카오톡처럼 처음에 등록해놓고 나중에 필요없다면 바꿔야 함.
        Intent intent = new Intent(MainActivity.this, SignUp.class );
        startActivity(intent);
    }
}
