package com.example.sat06.teamproject;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class parent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent);
    }

    public void onClick(View view) {//자녀 위치 찾기 버튼 클릭시 지도가 뜨면됨.
        Intent intent = new Intent(parent.this, mapMain.class );
        startActivity(intent);
    }

    public void onClick2(View view)
    {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:053-112"));
        startActivity(intent);
    }

    public void onClick3(View view)
    {
        Intent intent = new Intent(parent.this, graph.class);
        startActivity(intent);
    }
}
